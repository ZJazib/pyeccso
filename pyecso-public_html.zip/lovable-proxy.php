<?php
// PYECSO -> Lovable Cloud proxy.
// Forwards /_serverFn/* and /api/public/* to the Lovable-hosted backend so that
// AI translation, career notifications, job applications and HesabPay donations
// keep working on plain Apache hosting.
$upstream = 'https://pyeccso.lovable.app';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$query = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
if (strpos($path, '/_serverFn/') !== 0 && strpos($path, '/api/public/') !== 0) {
  http_response_code(404);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'Not found']);
  exit;
}
$target = $upstream . $path . ($query ? '?' . $query : '');

$method = $_SERVER['REQUEST_METHOD'];
$body = file_get_contents('php://input');

$forward = [];
foreach (getallheaders() as $name => $value) {
  $lower = strtolower($name);
  if (in_array($lower, ['host', 'content-length', 'accept-encoding', 'connection'], true)) continue;
  $forward[] = $name . ': ' . $value;
}
$forward[] = 'X-Forwarded-Host: ' . ($_SERVER['HTTP_HOST'] ?? '');

$ch = curl_init($target);
curl_setopt_array($ch, [
  CURLOPT_CUSTOMREQUEST => $method,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_FOLLOWLOCATION => false,
  CURLOPT_HTTPHEADER => $forward,
  CURLOPT_TIMEOUT => 60,
  CURLOPT_HEADER => true,
]);
if ($method !== 'GET' && $method !== 'HEAD') {
  curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
}
$response = curl_exec($ch);
if ($response === false) {
  http_response_code(502);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'Upstream unreachable', 'details' => curl_error($ch)]);
  curl_close($ch);
  exit;
}
$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
curl_close($ch);

$rawHeaders = substr($response, 0, $headerSize);
$payload = substr($response, $headerSize);

http_response_code($status);
foreach (explode("\r\n", $rawHeaders) as $line) {
  if (stripos($line, 'content-type:') === 0 || stripos($line, 'cache-control:') === 0) {
    header(trim($line));
  }
}
echo $payload;
